import React from "react";

const FormInput = (props) => {
  return (
    <div>
      <label htmlFor={props.id}>{props.labelName}</label>
      <input
        placeholder={props.placeholder || "..."}
        id={props.is}
        type={props.inputType}
      />
    </div>
  );
};

export default FormInput;
