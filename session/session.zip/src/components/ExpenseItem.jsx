import React from "react";

const ExpenseItem = ({ title, date, price }) => {
  return (
    <div>
      <p>{date.toString()}</p>
      <p>{title}</p>
      <p>{price}</p>
    </div>
  );
};

export default ExpenseItem;
