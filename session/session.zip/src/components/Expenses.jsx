import React from "react";
import ExpenseItem from "./ExpenseItem";

const Expenses = ({ expenses }) => {
  return (
    <ul>
      {expenses.map((elem) => {
        return (
          <div>
            <ExpenseItem
              title={elem.title}
              price={elem.price}
              date={elem.date}
            />
          </div>
        );
      })}
    </ul>
  );
};

export default Expenses;
