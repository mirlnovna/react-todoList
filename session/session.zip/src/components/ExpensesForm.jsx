import React from "react";
import Button from "../UI/button/input/Button";
import FormInput from "../UI/button/input/FormInput";

const ExpensesForm = (props) => {
  const cancelhandler = (e) => {
    e.preventDefault();
    props.onShowForm();
  };
  return (
    <form>
      <FormInput
        id="name"
        labelName="Название"
        inputType="текст"
        placeholder="Введите..."
      />
      <FormInput labelName="Количество" inputType="number" id="price" />
      <FormInput
        labelName="Дата"
        inputType="date"
        placeholder="дд.мм.гггг"
        id="date"
      />
      <Button title="Отмена" onClick={cancelhandler} />
      <Button title="Сохранить" />
    </form>
  );
};

export default ExpensesForm;
