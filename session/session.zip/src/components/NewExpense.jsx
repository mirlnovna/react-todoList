import React, { useState } from "react";
import Button from "../UI/button/input/Button";
import ExpensesForm from "./ExpensesForm";

const NewExpense = () => {
  const [state, setState] = useState(false);

  const newExpenseButtonClickHandler = () => {
    setState(() => true);
  };
  return (
    <div>
      {state ? (
        <ExpensesForm onShowForm={newExpenseButtonClickHandler} />
      ) : (
        <Button
          title="Добавить новый расхот"
          onClick={newExpenseButtonClickHandler}
        />
      )}
    </div>
  );
};

export default NewExpense;
