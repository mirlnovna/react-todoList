import "./App.css";
import Expenses from "./components/Expenses";
import NewExpense from "./components/NewExpense";

const expenses = [
  {
    title: "vdgg",
    price: 23,
    date: new Date(),
  },
];

function App() {
  return (
    <div className="App">
      <NewExpense />
      <Expenses expenses={expenses} />
    </div>
  );
}

export default App;
